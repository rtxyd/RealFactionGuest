﻿
using System.Collections.Generic;
using RimWorld;

using HarmonyLib;
using Verse;
using UnityEngine;
using System.Linq;
using Verse.AI;
using System;
using System.Reflection;
using RimWorld.Planet;
using RimWorld.QuestGen;


namespace raceQuestPawn
{
    public class harmonyPatch : Mod
    {
        public harmonyPatch(ModContentPack content) : base(content)
        {
            var harmony = new Harmony("raceQuestPawn");
            harmony.PatchAll();
        }
    }

    [HarmonyPatch(typeof(PawnGenerator), "GeneratePawn")]
    [HarmonyPatch(new Type[] { typeof(PawnGenerationRequest) })]
    public class patch_PawnGenerator_GeneratePawn
    {
        private static AccessTools.FieldRef<DrugPolicy, List<DrugPolicyEntry>> s_entriesInt = AccessTools.FieldRefAccess<DrugPolicy, List<DrugPolicyEntry>>("entriesInt");

        [HarmonyPriority(1000)]
        public static void Prefix(ref PawnGenerationRequest request)
        {
            try
            {
                if (Current.ProgramState != ProgramState.Playing) return;
                if (request.KindDef.RaceProps != null && (
                    request.KindDef.RaceProps.Animal
                    || request.KindDef.RaceProps.intelligence <= Intelligence.ToolUser
                    )) return;
                if (request.Faction != null && request.Faction.IsPlayer) return;
                if (request.KindDef == PawnKindDefOf.WildMan) return;

                Log.Message($"request : {(request.Faction != null ? request.Faction.def.defName : "none")}, {(request.KindDef != null ? request.KindDef.defName : "none")}");

                if (request.Faction != null && request.Faction.def.modContentPack != null && !request.Faction.def.modContentPack.PackageId.Contains("ludeon") && request.KindDef.modContentPack.PackageId.Contains("ludeon"))
                {
                    // 팩션이 있을때
                    FactionDef fd = request.Faction.def;
                    float combatPower = request.KindDef.combatPower;
                    PawnKindDef p_make = null;

                    List<PawnKindDef> allPawnKinds = new List<PawnKindDef>();
                    if (fd.pawnGroupMakers != null)
                    {
                        for (int index1 = 0; index1 < fd.pawnGroupMakers.Count; ++index1)
                        {
                            List<PawnGenOption> options = fd.pawnGroupMakers[index1].options;
                            for (int index2 = 0; index2 < options.Count; ++index2)
                            {
                                if (!allPawnKinds.Contains(options[index2].kind))
                                {
                                    allPawnKinds.Add(options[index2].kind);
                                }
                            }

                        }
                    }

                    foreach (PawnKindDef p in allPawnKinds)
                    {
                        if (p_make == null || Mathf.Abs(p_make.combatPower - combatPower) > Mathf.Abs(p.combatPower - combatPower))
                        {
                            p_make = p;
                        }
                    }

                    if (p_make != null)
                    {
                        request.KindDef = p_make;
                        Log.Message($"A : {p_make.defName} : {p_make.combatPower}");
                        return;
                    }

                }



                if (request.Faction == null || request.KindDef.defName.ToLower().Contains("refugee"))
                {
                    // 팩션이 없거나 조난자 일때
                    if (Rand.Value <= core.vanillaRatio) return;


                    float combatPower = request.KindDef.combatPower;

                    FactionDef fd = null;
                    PawnKindDef p_make = null;
                    List<PawnKindDef> allPawnKinds = new List<PawnKindDef>();
                    int tryCount = 0;

                    while (allPawnKinds.Count <= 0 && tryCount <= 11)
                    {
                        tryCount++;
                        fd = DefDatabase<FactionDef>.AllDefs.RandomElement<FactionDef>();

                        if (fd != null && fd.pawnGroupMakers != null && fd.modContentPack != null)
                        {
                            if (fd.modContentPack.PackageId.Contains("ludeon")) continue;
                            if (fd.modContentPack.PackageId.Contains("ogliss.alienvspredator")) continue;
                            if (fd.modContentPack.PackageId.Contains("Kompadt.Warhammer.Dryad")) continue;

                            for (int index1 = 0; index1 < fd.pawnGroupMakers.Count; ++index1)
                            {
                                List<PawnGenOption> options = fd.pawnGroupMakers[index1].options;
                                for (int index2 = 0; index2 < options.Count; ++index2)
                                {
                                    if (!allPawnKinds.Contains(options[index2].kind) && (options[index2].kind.RaceProps == null || options[index2].kind.RaceProps.intelligence == Intelligence.Humanlike || options[index2].kind.RaceProps.Humanlike))
                                    {

                                        Log.Message($"B0 : {fd.modContentPack.PackageId}");
                                        allPawnKinds.Add(options[index2].kind);

                                    }
                                }

                            }
                        }

                    }

                    foreach (PawnKindDef p in allPawnKinds)
                    {
                        if (p_make == null || Mathf.Abs(p_make.combatPower - combatPower) > Mathf.Abs(p.combatPower - combatPower))
                        {
                            p_make = p;
                        }
                    }
                    if (p_make != null && Mathf.Abs(request.KindDef.combatPower - p_make.combatPower) <= 30f)
                    {
                        request.KindDef = p_make;
                        Log.Message($"B : {p_make.defName} : {p_make.combatPower}");
                    }

                    return;
                }
            }
            catch
            {
                return;
            }


        }
    }



    /*
    [HarmonyPatch(typeof(QuestNode_GetRandomPawnKindForFaction), "SetVars")]
    internal class patch_QuestNode_GetRandomPawnKindForFaction_SetVars
    {
        private static FieldInfo f_equivalenceGroupTempStorage = AccessTools.Field(typeof(FloatMenuMakerMap), "equivalenceGroupTempStorage");
        private static AccessTools.FieldRef<FloatMenuOption[]> s_equivalenceGroupTempStorage = AccessTools.StaticFieldRefAccess<FloatMenuOption[]>(f_equivalenceGroupTempStorage);

        [HarmonyPostfix]
        static bool Prefix(ref bool __result, QuestNode_GetRandomPawnKindForFaction __instance, Slate slate)
        {
            Thing thing = __instance.factionOf.GetValue(slate);
            if (thing == null)
            {
                __result = false;
                return false;
            }
                
            Faction faction = thing.Faction;
            if (faction == null)
            {
                __result = false;
                return false;
            }
                
            List<QuestNode_GetRandomPawnKindForFaction.Choice> choiceList = __instance.choices.GetValue(slate);
            for (int index = 0; index < choiceList.Count; ++index)
            {
                PawnKindDef result;
                if ((choiceList[index].factionDef != null && faction.def == choiceList[index].factionDef || !choiceList[index].categoryTag.NullOrEmpty() && choiceList[index].categoryTag == faction.def.categoryTag) && choiceList[index].pawnKinds.TryRandomElement<PawnKindDef>(out result))
                {
                    slate.Set<PawnKindDef>(__instance.storeAs.GetValue(slate), result);
                    __result = true;
                    return false;
                }
            }

            // yayo
            if (!faction.def.modContentPack.Name.Contains("Ludeon"))
            {
                if (__instance.fallback.GetValue(slate) != null && __instance.fallback.GetValue(slate).defName.ToLower().Contains("refugee"))
                {
                    PawnKindDef p_make = null;
                    foreach (PawnKindDef p in from pawn in DefDatabase<PawnKindDef>.AllDefs
                                              where
                                                   pawn.defaultFactionType == faction.def
                                           select pawn)
                    {
                        if(p_make == null || Mathf.Abs(p_make.combatPower - 30f) > Mathf.Abs(p.combatPower - 30) )
                        {
                            p_make = p;
                        }

                    }
                    if(p_make != null) slate.Set<PawnKindDef>(__instance.storeAs.GetValue(slate), p_make);
                }
                else
                {
                    slate.Set<PawnKindDef>(__instance.storeAs.GetValue(slate), faction.RandomPawnKind());
                }
                
                __result = true;
                return false;
                
            }


            //

            if (__instance.fallback.GetValue(slate) == null)
            {
                __result = false;
                return false;
            }    
            slate.Set<PawnKindDef>(__instance.storeAs.GetValue(slate), __instance.fallback.GetValue(slate));
            __result = true;
            return false;

        }
    }
    */

}