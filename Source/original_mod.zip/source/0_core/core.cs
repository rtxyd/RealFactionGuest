﻿using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;
using UnityEngine;
using HugsLib;
using HugsLib.Settings;
using System.Linq;

namespace raceQuestPawn
{
    public class core : ModBase
    {
        public override string ModIdentifier => "raceQuestPawn";

        public static float vanillaRatio = 0.3f;

        /*
        private SettingHandle<bool> goalBiomeSetting;
        public static bool goalBiome = 3;

        private SettingHandle<float> extractSpeedSetting;
        public static float extractSpeed = 1f;
        */


        public override void DefsLoaded()
        {
            Log.Message("# Real Faction Guest - Init");

            int humanlikeModFactionNum = 0;

            foreach (FactionDef f in from faction in DefDatabase<FactionDef>.AllDefs
                                     where
                                        faction.modContentPack != null
                                        && faction.modContentPack.PackageId != null
                                        && !faction.modContentPack.PackageId.Contains("ludeon")
                                        && !faction.modContentPack.PackageId.Contains("ogliss.alienvspredator")
                                        && !faction.modContentPack.PackageId.Contains("Kompadt.Warhammer.Dryad")
                                     select faction)
            {
                try
                {
                    bool flag = false;
                    if (f.pawnGroupMakers == null) continue;

                    for (int index1 = 0; index1 < f.pawnGroupMakers.Count; ++index1)
                    {
                        List<PawnGenOption> options = f.pawnGroupMakers[index1].options;
                        for (int index2 = 0; index2 < options.Count; ++index2)
                        {
                            if ((options[index2].kind.RaceProps == null || options[index2].kind.RaceProps.intelligence == Intelligence.Humanlike || options[index2].kind.RaceProps.Humanlike))
                            {
                                flag = true;

                            }
                        }

                    }
                    if (flag)
                    {
                        Log.Message($"{f.defName} : {f.label}");
                        humanlikeModFactionNum++;
                    }
                }
                catch { }

            }

            vanillaRatio = 3f / ((float)humanlikeModFactionNum + 3f);

            Log.Message($"humanlikeModFactionNum : {humanlikeModFactionNum}");
            Log.Message($"vanillaRatio : {vanillaRatio}");

            Log.Message("# Real Faction Guest - Complete");
            /*
            // 셋팅
            goalBiomeSetting = Settings.GetHandle<int>("goalBiome", "goalBiome_title".Translate(), "goalBiome_desc".Translate(), 3);
            goalBiome = goalBiomeSetting.Value;

            extractSpeedSetting = Settings.GetHandle<float>("extractSpeed", "extractSpeed_title".Translate(), "extractSpeed_desc".Translate(), 1f);
            extractSpeed = extractSpeedSetting.Value;


            // 바이옴 에너지 조각 텍스쳐 수정
            int a = 0;
            foreach (ThingDef t in from thing in DefDatabase<ThingDef>.AllDefs
                                    where
                                        thing.defName.Contains("yy_gem_")
                                    select thing)
            {
                GraphicData gd = new GraphicData();
                gd.graphicClass = typeof(Graphic_Single);
                gd.texPath = $"yy_bep{a % 15}";
                t.graphicData = gd;
                a++;
            }
            */
        }




        /*
        public override void SettingsChanged()
        {
            goalBiome = goalBiomeSetting.Value;
            extractSpeed = Mathf.Clamp(extractSpeedSetting.Value, 0.01f, 50f);

        }
        */
    }


}
